package org.example;

public class BadClass {
    int int1;

    NormalClass otherClass;

    public void badMethod(){
        this.int1 = this.otherClass.getInt1();
        this.otherClass.setInt1(0);
        this.otherClass.setInt2(0);
        this.otherClass.setInt3(0);
    }
}
